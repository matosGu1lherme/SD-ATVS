ENUNCIADO - 1

O programa funciona recebendo comandos pelo terminal;

PWD: Mostra o diretório atual
CHDIR caminho-desejado: Troca o diretório corrente
GETFILES: Devolve uma lista dos arquivos presentes no diretório corrente
GETDIRS: Devolve uma lista dos diretórios presentes no diretório corrente
EXIT: finaliza

ENUNCIADO - 2

O programa funciona recebendo comandos pelo terminal;

ADDFILE nome-arquivo: Adicionar o arquivo da pasta Cliente para pasta servidor
DELETE nome-arquivo: Deleta o arquivo da pasta do Servidor
GETFILESLIST: Mostra a lista de arquivos na pasta do Servidor
GETFILE nome-arquivo: Manda um arquivo da pasta do Servidor pra pasta Cliente